
"""
Pluggable samplers for an 8-way weight vector used to prioritize roadmap categories.

Modes:
- "classical": Fast, NumPy-based Dirichlet/Monte Carlo (default, most scalable).
- "pennylane": Optional; uses a 3-qubit circuit with PennyLane's default.qubit/lightning.
- "qiskit":    Optional; uses a 3-qubit circuit with Qiskit Aer simulator.

Usage:
    from wormhole_samplers import sample8, CATEGORIES, get_available_modes
    weights = sample8(signals={"trend_strength":0.7,...}, mode="auto", seed=42)
"""
from __future__ import annotations
from typing import Dict, Optional, List, Tuple
import math, numpy as np
import os

CATEGORIES = [
    "latency", "retrieval", "security", "wallet",
    "mining", "zk", "coinjoin", "ui"
]

def _clip01(x: float) -> float:
    return max(0.0, min(1.0, float(x)))

def _rng(seed: Optional[int]):
    return np.random.default_rng(seed) if seed is not None else np.random.default_rng()

# ---------------------- Classical (scalable) ----------------------
def _classical_sampler(signals: Dict[str, float], seed: Optional[int]) -> np.ndarray:
    """
    Turn signals into a Dirichlet concentration vector and draw probabilities.
    Deterministic with seed. O(1) and very fast; great for production scale.
    """
    trend = _clip01(signals.get("trend_strength", 0.5))
    vol   = _clip01(signals.get("volatility", 0.5))
    dev   = _clip01(signals.get("dev_velocity", 0.5))
    frus  = _clip01(signals.get("user_frustration", 0.2))
    cost  = _clip01(signals.get("infra_cost", 0.4))
    sec   = _clip01(signals.get("security_findings", 0.1))

    # Hand-crafted mapping into positive concentrations (alpha > 0)
    alpha = np.array([
        0.6 + 3.0*frus + 0.8*vol,        # latency
        0.6 + 2.2*trend + 0.4*dev,       # retrieval
        0.6 + 3.2*sec + 0.6*vol,         # security
        0.6 + 1.6*frus + 0.6*trend,      # wallet
        0.6 + 1.2*dev  + 0.6*vol,        # mining
        0.6 + 1.4*dev  + 0.4*trend,      # zk
        0.6 + 0.8*vol  + 0.6*trend,      # coinjoin
        0.6 + 1.0*trend + 0.4*cost,      # ui
    ], dtype=float)

    # Small floor to avoid degenerate Dirichlet
    alpha = np.maximum(alpha, 1e-3)
    rng = _rng(seed)
    probs = rng.dirichlet(alpha)
    return probs

# ---------------------- PennyLane (optional) ----------------------
def _pennylane_sampler(signals: Dict[str, float], seed: Optional[int]) -> Optional[np.ndarray]:
    try:
        import pennylane as qml
    except Exception:
        return None

    trend = _clip01(signals.get("trend_strength", 0.5))
    vol   = _clip01(signals.get("volatility", 0.5))
    dev   = _clip01(signals.get("dev_velocity", 0.5))
    frus  = _clip01(signals.get("user_frustration", 0.2))
    cost  = _clip01(signals.get("infra_cost", 0.4))
    sec   = _clip01(signals.get("security_findings", 0.1))

    angleA = 2*math.pi*_clip01(trend + 0.15*dev)
    angleB = 2*math.pi*_clip01(0.5*vol + 0.5*frus)
    angleC = 2*math.pi*_clip01(0.6*sec + 0.4*cost)

    # Prefer lightning.qubit if present for speed; else default.qubit
    try:
        dev_pl = qml.device("lightning.qubit", wires=3, shots=4096, seed=seed)
    except Exception:
        dev_pl = qml.device("default.qubit", wires=3, shots=4096, seed=seed)

    @qml.qnode(dev_pl)
    def circuit(a, b, c):
        qml.RY(a, wires=0); qml.RZ(a/2, wires=0)
        qml.RY(b, wires=1); qml.RZ(b/2, wires=1)
        qml.RY(c, wires=2); qml.RZ(c/2, wires=2)
        qml.Hadamard(wires=0)
        qml.PauliX(wires=1)
        qml.SWAP(wires=[0,1])
        qml.CNOT(wires=[1,2])
        qml.Hadamard(wires=0)
        return qml.sample(wires=[0,1,2])

    try:
        samples = circuit(angleA, angleB, angleC)
    except Exception:
        return None

    # Convert samples (shots,3) into 8-prob vector
    counts = np.zeros(8, dtype=float)
    for q0,q1,q2 in samples:
        idx = (int(q0)<<2) | (int(q1)<<1) | int(q2)
        counts[idx] += 1.0
    probs = (counts + 1e-9) / (counts.sum() + 8e-9)
    return probs

# ---------------------- Qiskit (optional) ----------------------
def _qiskit_sampler(signals: Dict[str, float], seed: Optional[int]) -> Optional[np.ndarray]:
    try:
        from qiskit import QuantumCircuit, Aer, execute
        from qiskit.utils import algorithm_globals
    except Exception:
        return None

    algorithm_globals.random_seed = seed if seed is not None else 1234

    trend = _clip01(signals.get("trend_strength", 0.5))
    vol   = _clip01(signals.get("volatility", 0.5))
    dev   = _clip01(signals.get("dev_velocity", 0.5))
    frus  = _clip01(signals.get("user_frustration", 0.2))
    cost  = _clip01(signals.get("infra_cost", 0.4))
    sec   = _clip01(signals.get("security_findings", 0.1))

    angleA = 2*math.pi*_clip01(trend + 0.15*dev)
    angleB = 2*math.pi*_clip01(0.5*vol + 0.5*frus)
    angleC = 2*math.pi*_clip01(0.6*sec + 0.4*cost)

    qc = QuantumCircuit(3,3)
    for i,a in enumerate([angleA, angleB, angleC]):
        qc.ry(a, i); qc.rz(a/2, i)
    qc.h(0); qc.x(1); qc.swap(0,1); qc.cx(1,2); qc.h(0)
    qc.measure([0,1,2],[0,1,2])

    try:
        backend = Aer.get_backend('qasm_simulator')
    except Exception:
        return None

    job = execute(qc, backend, shots=4096, seed_simulator=seed, seed_transpiler=seed)
    result = job.result()
    counts = result.get_counts()
    total = sum(counts.values())
    probs = np.zeros(8, dtype=float)
    for bits, c in counts.items():
        idx = int(bits, 2)
        probs[idx] = c / total
    probs = (probs + 1e-9) / (probs.sum() + 8e-9)
    return probs

# ---------------------- Public API ----------------------
def get_available_modes() -> List[str]:
    modes = ["classical"]
    try:
        import pennylane  # noqa
        modes.append("pennylane")
    except Exception:
        pass
    try:
        import qiskit  # noqa
        modes.append("qiskit")
    except Exception:
        pass
    return modes

def sample8(signals: Dict[str, float], mode: str = "auto", seed: Optional[int] = None) -> np.ndarray:
    """
    Returns an 8-length probability vector corresponding to CATEGORIES order.
    If mode == "auto", prefers PennyLane (fast) if available, else "classical".
    """
    mode = (mode or "auto").lower().strip()
    if mode == "auto":
        # Prefer PennyLane for speed if installed; else classical
        probs = _pennylane_sampler(signals, seed)
        if probs is None:
            probs = _classical_sampler(signals, seed)
        return probs

    if mode == "pennylane":
        probs = _pennylane_sampler(signals, seed)
        if probs is None:
            raise RuntimeError("PennyLane not available or failed.")
        return probs

    if mode == "qiskit":
        probs = _qiskit_sampler(signals, seed)
        if probs is None:
            raise RuntimeError("Qiskit not available or failed.")
        return probs

    # Fallback/default
    return _classical_sampler(signals, seed)
