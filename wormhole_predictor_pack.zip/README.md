
# Wormhole Predictor (Escalable)

Este pack te da un **módulo de priorización de roadmap** con un sampler **enchufable**:

- **classical** (por defecto): NumPy + Dirichlet. Ultra rápido y reproducible → **lo más escalable**.
- **pennylane** (opcional): si ya tienes PennyLane, usa `lightning.qubit` cuando esté disponible.
- **qiskit** (opcional): compatible con tu snippet; más pesado.

## Integración rápida

1. Copia `wormhole_samplers.py`, `wormhole_predictor_core.py` y `quantum_chat_blueprint.py` a tu repo (ej. raíz o módulo).
2. Registra el blueprint en Flask:
   ```python
   from quantum_chat_blueprint import qnn_route
   app.register_blueprint(qnn_route, url_prefix="/qnn")
   ```
3. (Opcional) Configura el modo por variable de entorno:
   ```bash
   export WORMHOLE_SAMPLER_MODE=classical   # auto|classical|pennylane|qiskit
   ```
4. Llama al endpoint:
   ```bash
   curl -X POST http://127.0.0.1:5000/qnn/infer \
     -H "Content-Type: application/json" \
     -d '{"prompt":"mejora el wallet", "mode":"auto"}'
   ```

## Señales
Sustituye `_default_signals()` por tu telemetría real (latencia p95, error rate, commits, issues, métricas de tu chain, etc.).

## ¿Por qué "classical" es lo más escalable?
- Sin dependencias pesadas ni simuladores.
- Latencia ultra baja y constante (microsegundos–milisegundos).
- Determinístico con `seed`, seguro en threads y fácil de paralelizar.
- Puedes cambiar la forma de las concentraciones Dirichlet sin tocar nada más.

## Extras
- `pennylane`: necesitarás `pennylane` (y opcionalmente `pennylane-lightning`).
- `qiskit`: necesitarás `qiskit` y `qiskit-aer`.

## Pruebas rápidas
```python
from wormhole_predictor_core import predict_roadmap
out = predict_roadmap({
  "trend_strength":0.7,"volatility":0.3,"dev_velocity":0.6,
  "user_frustration":0.2,"infra_cost":0.4,"security_findings":0.1
}, mode="classical", seed=42)
print(out)
```
