
from flask import Blueprint, jsonify, request
import os
from wormhole_predictor_core import predict_roadmap

qnn_route = Blueprint("qnn", __name__)

def _default_signals():
    # TODO: Sustituye por telemetría real
    return {
        "trend_strength": 0.7,
        "volatility": 0.35,
        "dev_velocity": 0.6,
        "user_frustration": 0.25,
        "infra_cost": 0.4,
        "security_findings": 0.2,
    }

@qnn_route.post("/infer")
def infer():
    data = request.get_json(silent=True) or {}
    prompt = (data.get("prompt") or "").strip()
    signals = data.get("signals") or _default_signals()
    # mode: "auto" | "classical" | "pennylane" | "qiskit"
    mode = data.get("mode") or os.getenv("WORMHOLE_SAMPLER_MODE", "auto")
    seed = data.get("seed")
    pred = predict_roadmap(signals, mode=mode, seed=seed)
    return jsonify({
        "prompt": prompt,
        "signals": signals,
        "roadmap": pred
    })
