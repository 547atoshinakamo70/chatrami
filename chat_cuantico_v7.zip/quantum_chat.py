﻿from flask import Blueprint, jsonify, request

qnn_route = Blueprint("qnn", __name__)

def qnn_infer(prompt: str):
    prompt = (prompt or "").strip()
    nets = [f"net-{i:02d}" for i in range(1, 33)]
    parts = [{"id": n, "text": f"[{n}] {prompt[:64]}  "} for n in nets]
    return {"combined": f"Sugerencia combinada para: '{prompt}'", "parts": parts}

@qnn_route.post("/infer")
def infer():
    data = request.get_json(silent=True) or {}
    prompt = data.get("prompt", "")
    return jsonify(qnn_infer(prompt))
