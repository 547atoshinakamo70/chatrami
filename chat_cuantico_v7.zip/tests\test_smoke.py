﻿from main import create_app

def test_index():
    app = create_app()
    c = app.test_client()
    r = c.get("/")
    assert r.status_code == 200


def test_qnn():
    app = create_app()
    c = app.test_client()
    r = c.post("/qnn/infer", json={"prompt": "hola"})
    assert r.status_code == 200
    assert "combined" in r.get_json()
