﻿from flask import Flask, render_template
from dotenv import load_dotenv

from quantum_chat import qnn_route
from cannabis_agent import agents_bp
from research_agent import research_bp

load_dotenv()

def create_app():
    app = Flask(__name__)
    app.register_blueprint(qnn_route, url_prefix="/qnn")
    app.register_blueprint(agents_bp, url_prefix="/agents")
    app.register_blueprint(research_bp, url_prefix="/research")

    @app.route("/")
    def index():
        return render_template("index.html")

    @app.route("/chat")
    def chat_page():
        return render_template("chat.html")

    @app.route("/api-docs")
    def api_docs():
        return render_template("api_docs.html")

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(host="127.0.0.1", port=5000, debug=True)
