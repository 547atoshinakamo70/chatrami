﻿from flask import Blueprint, jsonify, request

agents_bp = Blueprint("agents", __name__)

@agents_bp.post("/run")
def run_agents():
    data = request.get_json(silent=True) or {}
    prompt = (data.get("prompt") or "").strip()
    agents = [
        {"name": "planner", "out": f"plan -> {prompt[:40]}"},
        {"name": "retriever", "out": "k=5 docs"},
        {"name": "qnn", "out": "32 nets OK"},
        {"name": "writer", "out": "draft v1"},
        {"name": "critic", "out": "mejorar seccion 2"},
        {"name": "polish", "out": "tono pro"},
        {"name": "guard", "out": "seguro y coherente"},
    ]
    return jsonify({"prompt": prompt, "agents": agents, "result": "OK"})
