﻿# Chat Cuántico v7.0 (Workspace)

Proyecto base Flask para sistema multi-agente con QNN (mock inicial), conectores, búsqueda web y UI mínima.

## Windows PowerShell
cd "$env:USERPROFILE\Desktop\chat_cuantico_v7"
python -m venv .venv
.\.venv\Scripts\pip install -r requirements.txt
.\.venv\Scripts\python main.py
# http://127.0.0.1:5000
